const { useState, useMemo, useSyncExternalStore, useEffect } = React;

// Persistent socket
const room = new WebsimSocket();

// Record type names (versioned for schema control)
const TYPES = {
  admin: 'admin_v1',
  player: 'player_v1',
  team: 'team_v1',
  match: 'match_v1',
};

// Default image for players without an image
const DEFAULT_PLAYER_IMG = '/a/ac7fc452-cbc7-41ba-a896-69d2dcba3d62';
// Canonical league teams
const TEAM_NAMES = ['Marineros del Caribe', 'Halcones Dorados'];
function filterCanonicalTeams(teams) {
  return teams.filter(t => TEAM_NAMES.includes(t.name));
}

// Utilities
function formatDate(dStr) {
  if (!dStr) return '';
  const d = new Date(dStr);
  return d.toLocaleDateString();
}
function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
// value = base 100k + goals*500k + assists*300k
function computePlayerValue(p) {
  const g = Number(p.goals) || 0, a = Number(p.assists) || 0;
  return 100000 + g * 500000 + a * 300000;
}
function formatMoney(n) {
  return '$' + (Number(n)||0).toLocaleString();
}

// Record hooks
function useList(type, filter = null) {
  const coll = filter ? room.collection(type).filter(filter) : room.collection(type);
  return useSyncExternalStore(coll.subscribe, coll.getList);
}

// Admin/Guest start gate
function StartGate({ onChooseAdmin, onChooseGuest }) {
  return (
    <div className="login-overlay">
      <div className="login-card">
        <div className="title">Choose Mode</div>
        <div className="small" style={{ marginTop: 6 }}>Admin can add/edit data. Guest is read-only.</div>
        <div className="row" style={{ marginTop: 10 }}>
          <button className="primary" onClick={onChooseAdmin}>Login as Admin</button>
          <button className="" onClick={onChooseGuest}>Continue as Guest</button>
        </div>
      </div>
    </div>
  );
}

// Admin auth
async function ensureAdminPasswordExists() {
  const list = room.collection(TYPES.admin).getList();
  if (list.length === 0) {
    // create default: admin123
    await room.collection(TYPES.admin).create({
      password: 'admin123',
    });
  }
}
function LoginGate({ onAuthed }) {
  const adminList = useList(TYPES.admin);
  const [pwd, setPwd] = useState(''); 
  const [error, setError] = useState('');

  useEffect(() => {
    ensureAdminPasswordExists();
  }, []);

  function submit() {
    const current = adminList[adminList.length - 1]; // latest
    const valid = current && pwd === current.password;
    if (valid) {
      onAuthed(true);
      setError('');
      setPwd('');
    } else {
      setError('Invalid password');
    }
  }

  async function setNewPassword() {
    if (pwd.trim().length < 4) {
      setError('Password too short');
      return;
    }
    let current = adminList[adminList.length - 1];
    if (!current) {
      current = await room.collection(TYPES.admin).create({ password: pwd });
    } else {
      try {
        await room.collection(TYPES.admin).update(current.id, { password: pwd });
      } catch (e) {
        // If not allowed to update, create a new admin record you own
        await room.collection(TYPES.admin).create({ password: pwd });
      }
    }
    onAuthed(true);
  }

  return (
    <div className="login-overlay">
      <div className="login-card">
        <div className="title">Admin Login</div>
        <div className="small">Default password: admin123</div>
        <div className="input-row" style={{ marginTop: 8 }}>
          <input
            type="password"
            placeholder="Enter admin password"
            value={pwd}
            onChange={(e) => setPwd(e.target.value)}
          />
        </div>
        <div className="row">
          <button className="primary" onClick={submit}>Login</button>
          <button className="secondary" onClick={setNewPassword}>Set as new password</button>
        </div>
        {error && <div className="small" style={{ color: 'tomato', marginTop: 8 }}>{error}</div>}
      </div>
    </div>
  );
}

// Players
function PlayerForm({ onSave, onCancel, initial }) {
  const [name, setName] = useState(initial?.name || '');
  const [number, setNumber] = useState(initial?.number ?? '');
  const [position, setPosition] = useState(initial?.position || '');
  const [teamId, setTeamId] = useState(initial?.team_id || '');
  const [goals, setGoals] = useState(initial?.goals ?? 0);
  const [assists, setAssists] = useState(initial?.assists ?? 0);
  const [yellows, setYellows] = useState(initial?.yellow_cards ?? 0);
  const [reds, setReds] = useState(initial?.red_cards ?? 0);
  const [saves, setSaves] = useState(initial?.saves ?? 0);
  const [conceded, setConceded] = useState(initial?.goals_conceded ?? 0);
  const [avatarUrl, setAvatarUrl] = useState(initial?.avatar_url || '');
  const teams = useList(TYPES.team);
  const canonicalTeams = filterCanonicalTeams(teams);

  async function handleUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await websim.upload(file);
      setAvatarUrl(url);
    } catch (err) {
      console.error(err);
      alert('Upload failed');
    }
  }

  function save() {
    if (!name.trim()) return alert('Name required');
    onSave({
      name,
      number: number ? Number(number) : null,
      position,
      team_id: teamId || null,
      goals: Number(goals) || 0,
      assists: Number(assists) || 0,
      yellow_cards: Number(yellows) || 0,
      red_cards: Number(reds) || 0,
      saves: Number(saves) || 0,
      goals_conceded: Number(conceded) || 0,
      avatar_url: avatarUrl || null,
    });
  }

  return (
    <div className="panel">
      <div className="section-title">{initial ? 'Edit Player' : 'Add Player'}</div>
      <div className="grid">
        <div>
          <div className="input-row">
            <div className="field">
              <label>Name</label>
              <input type="text" placeholder="Name" value={name} onChange={(e)=>setName(e.target.value)} />
            </div>
            <div className="field">
              <label>Number</label>
              <input type="number" placeholder="Number" value={number} onChange={(e)=>setNumber(e.target.value)} />
            </div>
          </div>
          <div className="input-row">
            <div className="field">
              <label>Position</label>
              <input type="text" placeholder="Position (e.g., GK, ST)" value={position} onChange={(e)=>setPosition(e.target.value)} />
            </div>
            <div className="field">
              <label>Team</label>
              <select value={teamId} onChange={(e)=>setTeamId(e.target.value)}>
                <option value="">No team</option>
                {canonicalTeams.slice().reverse().map(t => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="input-row">
            <div className="field">
              <label>Goals</label>
              <input type="number" placeholder="Goals" value={goals} onChange={(e)=>setGoals(e.target.value)} />
            </div>
            <div className="field">
              <label>Assists</label>
              <input type="number" placeholder="Assists" value={assists} onChange={(e)=>setAssists(e.target.value)} />
            </div>
          </div>
          <div className="input-row">
            <div className="field">
              <label>Yellow cards</label>
              <input type="number" placeholder="Yellow cards" value={yellows} onChange={(e)=>setYellows(e.target.value)} />
            </div>
            <div className="field">
              <label>Red cards</label>
              <input type="number" placeholder="Red cards" value={reds} onChange={(e)=>setReds(e.target.value)} />
            </div>
          </div>
          <div className="input-row">
            <div className="field">
              <label>Saves (GK)</label>
              <input type="number" placeholder="Saves made" value={saves} onChange={(e)=>setSaves(e.target.value)} />
            </div>
            <div className="field">
              <label>Goals conceded (GK)</label>
              <input type="number" placeholder="Goals conceded" value={conceded} onChange={(e)=>setConceded(e.target.value)} />
            </div>
          </div>
        </div>
        <div>
          <div className="input-row">
            <div className="field">
              <label>Avatar URL (optional)</label>
              <input type="text" placeholder="Avatar URL (optional)" value={avatarUrl} onChange={(e)=>setAvatarUrl(e.target.value)} />
            </div>
          </div>
          <div className="input-row">
            <input type="file" accept="image/*" onChange={handleUpload} />
          </div>
          {avatarUrl ? <img className="avatar" src={avatarUrl} alt="" /> : <div className="small">No avatar</div>}
        </div>
      </div>
      <div className="row" style={{ marginTop: 8 }}>
        <button className="primary" onClick={save}>{initial ? 'Save' : 'Create'}</button>
        <button onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}

function PlayersManager({ authed }) {
  const players = useList(TYPES.player);
  const teams = useList(TYPES.team);
  const canonicalTeams = filterCanonicalTeams(teams);
  const [editing, setEditing] = useState(null);
  const [adding, setAdding] = useState(false);
  const [query, setQuery] = useState('');

  const teamById = useMemo(() => {
    const map = new Map();
    canonicalTeams.forEach(t => map.set(t.id, t));
    return map;
  }, [canonicalTeams]);

  async function createPlayer(data) {
    await room.collection(TYPES.player).create(data);
    setAdding(false);
  }
  async function updatePlayer(id, data) {
    try {
      await room.collection(TYPES.player).update(id, data);
    } catch (e) {
      alert('You can only edit players you created.');
    }
    setEditing(null);
  }
  async function deletePlayer(id) {
    try {
      await room.collection(TYPES.player).delete(id);
    } catch (e) {
      alert('You can only delete players you created.');
    }
  }

  const filtered = players.slice().reverse().filter(p => {
    const q = query.trim().toLowerCase();
    if (!q) return true;
    const team = teamById.get(p.team_id)?.name || '';
    return [p.name, p.position, team].some(s => (s||'').toLowerCase().includes(q));
  });

  return (
    <div className="panel">
      <div className="section-title">Players</div>
      <div className="row" style={{ marginBottom: 8 }}>
        <input type="text" placeholder="Search name / position / team" value={query} onChange={(e)=>setQuery(e.target.value)} />
        {authed && <button className="primary" onClick={()=>setAdding(true)}>Add Player</button>}
      </div>

      {adding && authed && (
        <PlayerForm onSave={createPlayer} onCancel={()=>setAdding(false)} />
      )}

      <div className="list">
        {filtered.map(p => (
          <div key={p.id} className="item">
            <img className="avatar" src={p.avatar_url || DEFAULT_PLAYER_IMG} alt="" />
            <div className="meta">
              <div><strong>#{p.number || '—'} {p.name}</strong> <span className="small">({p.position || '—'})</span></div>
              <div className="small">
                Team: {teamById.get(p.team_id)?.name || '—'} ·
                Goals: {p.goals || 0} · Assists: {p.assists || 0} ·
                YC: {p.yellow_cards || 0} · RC: {p.red_cards || 0} ·
                Saves: {p.saves || 0} · Conceded: {p.goals_conceded || 0}
              </div>
            </div>
            {authed && (
              <div className="controls">
                <button onClick={()=>setEditing(p)}>Edit</button>
                <button className="danger" onClick={()=>deletePlayer(p.id)}>Delete</button>
              </div>
            )}
          </div>
        ))}
      </div>

      {editing && authed && (
        <div style={{ marginTop: 10 }}>
          <PlayerForm
            initial={editing}
            onSave={(data)=>updatePlayer(editing.id, data)}
            onCancel={()=>setEditing(null)}
          />
        </div>
      )}
    </div>
  );
}

// Market section
function Market({ authed }) {
  const players = useList(TYPES.player);
  const teams = useList(TYPES.team);
  const teamById = useMemo(() => {
    const m = new Map(); teams.forEach(t => m.set(t.id, t)); return m;
  }, [teams]);
  const ranked = players.slice().reverse().map(p => ({ p, value: computePlayerValue(p) }))
    .sort((a,b)=>b.value - a.value);
  return (
    <div className="panel">
      <div className="section-title">Market Values</div>
      <div className="list">
        {ranked.map(({p,value})=>(
          <div key={p.id} className="item">
            <img className="avatar" src={p.avatar_url || DEFAULT_PLAYER_IMG} alt="" />
            <div className="meta">
              <div><strong>#{p.number || '—'} {p.name}</strong> <span className="small">({p.position || '—'})</span></div>
              <div className="small">Team: {teamById.get(p.team_id)?.name || '—'} · Goals: {p.goals||0} · Assists: {p.assists||0}</div>
            </div>
            <div className="controls"><button className="secondary">{formatMoney(value)}</button></div>
          </div>
        ))}
      </div>
    </div>
  );
}

// League: two teams, matches, standings
async function ensureDefaultTeams() {
  const teams = room.collection(TYPES.team).getList();
  const namesPresent = new Set(teams.map(t => t.name));
  for (const name of TEAM_NAMES) {
    if (!namesPresent.has(name)) {
      try {
        await room.collection(TYPES.team).create({ name });
      } catch (e) {}
    }
  }
  // Attempt to remove any non-canonical teams (only succeeds for teams created by the current user)
  const extras = teams.filter(t => !TEAM_NAMES.includes(t.name));
  for (const t of extras) {
    try {
      await room.collection(TYPES.team).delete(t.id);
    } catch (e) {
      // ignore if cannot delete (not owned)
    }
  }
}

function computeStandings(teams, matches) {
  const table = new Map();
  teams.forEach(t => {
    table.set(t.id, { team: t, played: 0, wins: 0, draws: 0, losses: 0, gf: 0, ga: 0, gd: 0, pts: 0 });
  });
  matches.forEach(m => {
    if (!table.has(m.home_team_id) || !table.has(m.away_team_id)) return;
    const h = table.get(m.home_team_id);
    const a = table.get(m.away_team_id);
    const hs = Number(m.home_score) || 0;
    const as = Number(m.away_score) || 0;
    h.played++; a.played++;
    h.gf += hs; h.ga += as; h.gd = h.gf - h.ga;
    a.gf += as; a.ga += hs; a.gd = a.gf - a.ga;
    if (hs > as) { h.wins++; a.losses++; h.pts += 3; }
    else if (hs < as) { a.wins++; h.losses++; a.pts += 3; }
    else { h.draws++; a.draws++; h.pts += 1; a.pts += 1; }
  });
  return Array.from(table.values()).sort((x,y)=>{
    if (y.pts !== x.pts) return y.pts - x.pts;
    if (y.gd !== x.gd) return y.gd - x.gd;
    return y.gf - x.gf;
  });
}

function TeamEditor({ team, onSave }) {
  const [name, setName] = useState(team?.name || '');
  const [avatarUrl, setAvatarUrl] = useState(team?.avatar_url || '');

  async function handleUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await websim.upload(file);
      setAvatarUrl(url);
    } catch (err) {
      console.error(err);
      alert('Upload failed');
    }
  }

  return (
    <div className="input-row" style={{ flexDirection: 'column', alignItems: 'stretch' }}>
      <div className="input-row">
        <input type="text" value={name} onChange={(e)=>setName(e.target.value)} placeholder="Team name" />
        <input type="text" value={avatarUrl} onChange={(e)=>setAvatarUrl(e.target.value)} placeholder="Team image URL (optional)" />
      </div>
      <div className="input-row">
        <input type="file" accept="image/*" onChange={handleUpload} />
        <button onClick={()=>onSave({ name, avatar_url: avatarUrl || null })}>Save</button>
      </div>
      {avatarUrl ? <img className="avatar" src={avatarUrl} alt="" /> : <div className="small">No image</div>}
    </div>
  );
}

function MatchForm({ teams, onSave, onCancel, initial }) {
  const [homeId, setHomeId] = useState(initial?.home_team_id || (teams[0]?.id || ''));
  const [awayId, setAwayId] = useState(initial?.away_team_id || (teams[1]?.id || ''));
  const [homeScore, setHomeScore] = useState(initial?.home_score ?? 0);
  const [awayScore, setAwayScore] = useState(initial?.away_score ?? 0);
  const [date, setDate] = useState(initial?.date || new Date().toISOString().slice(0,10));
  // New: per-goal events
  const players = useList(TYPES.player);
  const [goals, setGoals] = useState(() => Array.isArray(initial?.goals) ? initial.goals : []);

  const playersByTeam = React.useMemo(() => {
    const map = new Map();
    teams.forEach(t => map.set(t.id, players.filter(p => p.team_id === t.id)));
    return map;
  }, [players, teams]);

  function totalGoals() { return (Number(homeScore)||0) + (Number(awayScore)||0); }

  function autoFillGoals() {
    const total = totalGoals();
    const next = [];
    for (let i=0;i<total;i++){
      const isHome = i < (Number(homeScore)||0);
      next.push({
        team_id: isHome ? homeId : awayId,
        scorer_id: null,
        assist_id: null,
      });
    }
    setGoals(next);
  }

  function updateGoal(idx, patch) {
    setGoals(g => g.map((it,i)=> i===idx ? { ...it, ...patch } : it));
  }

  function save() {
    if (!homeId || !awayId || homeId === awayId) {
      return alert('Choose two distinct teams');
    }
    const total = totalGoals();
    if (goals.length !== total) {
      return alert(`Please create ${total} goal entries (currently ${goals.length}). Use "Auto-fill goals".`);
    }
    onSave({
      home_team_id: homeId,
      away_team_id: awayId,
      home_score: Number(homeScore) || 0,
      away_score: Number(awayScore) || 0,
      date,
      goals: goals.map(g => ({
        team_id: g.team_id || null,
        scorer_id: g.scorer_id || null,
        assist_id: g.assist_id || null,
      })),
    });
  }

  return (
    <div className="panel">
      <div className="section-title">{initial ? 'Edit Match' : 'Add Match'}</div>
      <div className="grid">
        <div>
          <div className="input-row">
            <select value={homeId} onChange={(e)=>setHomeId(e.target.value)}>
              {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
            <select value={awayId} onChange={(e)=>setAwayId(e.target.value)}>
              {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
          <div className="input-row">
            <input type="number" value={homeScore} onChange={(e)=>setHomeScore(e.target.value)} />
            <input type="number" value={awayScore} onChange={(e)=>setAwayScore(e.target.value)} />
          </div>
          <div className="input-row">
            <input type="date" value={date} onChange={(e)=>setDate(e.target.value)} />
          </div>

          <div className="section-title">Goals ({goals.length}/{totalGoals()})</div>
          <div className="row" style={{ marginBottom: 6 }}>
            <button onClick={autoFillGoals}>Auto-fill goals</button>
            <button onClick={()=>setGoals(g=>g.concat({ team_id: homeId, scorer_id: null, assist_id: null }))}>+ Add goal</button>
            <button onClick={()=>setGoals(g=>g.slice(0,-1))} disabled={goals.length===0}>- Remove last</button>
          </div>
          <div className="list">
            {goals.map((g, idx) => {
              const teamPlayers = playersByTeam.get(g.team_id) || [];
              return (
                <div key={idx} className="item">
                  <div className="meta" style={{flex:1}}>
                    <div className="small" style={{marginBottom:6}}>Goal #{idx+1}</div>
                    <div className="input-row">
                      <select value={g.team_id || ''} onChange={(e)=>updateGoal(idx, { team_id: e.target.value, scorer_id: null, assist_id: null })}>
                        <option value="">Select team</option>
                        {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                      </select>
                      <select value={g.scorer_id || ''} onChange={(e)=>updateGoal(idx, { scorer_id: e.target.value })}>
                        <option value="">Scorer</option>
                        {teamPlayers.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                      <select value={g.assist_id || ''} onChange={(e)=>updateGoal(idx, { assist_id: e.target.value })}>
                        <option value="">Assist (optional)</option>
                        {teamPlayers.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                    </div>
                  </div>
                  <div className="controls">
                    <button className="danger" onClick={()=>setGoals(gs => gs.filter((_,i)=>i!==idx))}>Delete</button>
                  </div>
                </div>
              );
            })}
            {goals.length===0 && <div className="small">No goals added yet.</div>}
          </div>
        </div>
      </div>
      <div className="row" style={{ marginTop: 8 }}>
        <button className="primary" onClick={save}>{initial ? 'Save' : 'Create'}</button>
        <button onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}

function LeagueManager({ authed }) {
  const teams = useList(TYPES.team);
  const canonicalTeams = filterCanonicalTeams(teams);
  const matches = useList(TYPES.match);
  const players = useList(TYPES.player);
  const [editingTeamId, setEditingTeamId] = useState(null);
  const [addingMatch, setAddingMatch] = useState(false);
  const [editingMatch, setEditingMatch] = useState(null);

  useEffect(() => { ensureDefaultTeams(); }, []);

  async function saveTeam(id, data) {
    try {
      await room.collection(TYPES.team).update(id, data);
    } catch (e) {
      alert('You can only edit teams you created.');
    }
    setEditingTeamId(null);
  }

  async function addMatch(data) {
    await room.collection(TYPES.match).create(data);
    setAddingMatch(false);
  }
  async function updateMatch(id, data) {
    try {
      await room.collection(TYPES.match).update(id, data);
    } catch (e) {
      alert('You can only edit matches you created.');
    }
    setEditingMatch(null);
  }
  async function deleteMatch(id) {
    try {
      await room.collection(TYPES.match).delete(id);
    } catch (e) {
      alert('You can only delete matches you created.');
    }
  }

  const topTwoTeams = canonicalTeams.slice().reverse().slice(0,2);
  const validTeamIds = new Set(topTwoTeams.map(t=>t.id));
  const leagueMatches = matches.slice().reverse().filter(m => validTeamIds.has(m.home_team_id) && validTeamIds.has(m.away_team_id));
  const standings = computeStandings(topTwoTeams, leagueMatches);

  function playerName(id) {
    const p = players.find(x => x.id === id);
    return p ? p.name : '—';
  }

  return (
    <div className="panel">
      <div className="section-title">League (Two Teams)</div>
      <div className="grid">
        <div>
          <div className="section-title">Teams</div>
          <div className="list">
            {topTwoTeams.map(t => (
              <div key={t.id} className="item">
                <img className="avatar" src={t.avatar_url || 'https://images.websim.com/avatar/' + (t.username || 'team')} alt="" />
                <div className="meta">
                  <strong>{t.name}</strong>
                  <div className="small">ID: {t.id.slice(0,8)}…</div>
                </div>
                {authed && (
                  <div className="controls">
                    {editingTeamId === t.id ? (
                      <TeamEditor team={t} onSave={(data)=>saveTeam(t.id, data)} />
                    ) : (
                      <button onClick={()=>setEditingTeamId(t.id)}>Edit</button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="section-title">Standings</div>
          <div className="standings-table">
            <div className="standings-header" style={{display:'grid',gridTemplateColumns:'1fr auto'}}><span>Team</span><span>Points</span></div>
            {standings.map(row => (
              <div key={row.team.id} className="standings-row"><div><strong>{row.team.name}</strong></div><div><strong>{row.pts}</strong></div></div>
            ))}
          </div>
        </div>
      </div>

      <div className="section-title" style={{ marginTop: 12 }}>Matches</div>
      <div className="row" style={{ marginBottom: 8 }}>
        {authed && <button className="primary" onClick={()=>setAddingMatch(true)}>Add Match</button>}
      </div>
      {addingMatch && authed && (
        <MatchForm
          teams={topTwoTeams}
          onSave={addMatch}
          onCancel={()=>setAddingMatch(false)}
        />
      )}
      <div className="list">
        {leagueMatches.map(m => {
          const ht = topTwoTeams.find(t=>t.id===m.home_team_id);
          const at = topTwoTeams.find(t=>t.id===m.away_team_id);
          return (
            <div key={m.id} className="item">
              <div className="meta">
                <strong>{ht?.name || '—'} {m.home_score} - {m.away_score} {at?.name || '—'}</strong>
                <div className="small">{formatDate(m.date)}</div>
                {Array.isArray(m.goals) && m.goals.length > 0 && (
                  <div className="small">
                    Scorers: {m.goals.map((g, i) => {
                      const team = topTwoTeams.find(t => t.id === g.team_id);
                      const scorer = playerName(g.scorer_id);
                      const assist = g.assist_id ? playerName(g.assist_id) : null;
                      return `${team?.name ? team.name + ': ' : ''}${scorer}${assist ? ' (Ast: ' + assist + ')' : ''}${i < m.goals.length - 1 ? ' · ' : ''}`;
                    })}
                  </div>
                )}
              </div>
              {authed && (
                <div className="controls">
                  <button onClick={()=>setEditingMatch(m)}>Edit</button>
                  <button className="danger" onClick={()=>deleteMatch(m.id)}>Delete</button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {editingMatch && authed && (
        <div style={{ marginTop: 10 }}>
          <MatchForm
            initial={editingMatch}
            teams={topTwoTeams}
            onSave={(data)=>updateMatch(editingMatch.id, data)}
            onCancel={()=>setEditingMatch(null)}
          />
        </div>
      )}
    </div>
  );
}

function TeamView() {
  const teams = useList(TYPES.team);
  const canonicalTeams = filterCanonicalTeams(teams);
  const players = useList(TYPES.player);
  const matches = useList(TYPES.match);
  const [selectedId, setSelectedId] = useState(canonicalTeams.slice().reverse()[0]?.id || '');

  useEffect(() => {
    const latest = canonicalTeams.slice().reverse()[0];
    if (latest && !selectedId) setSelectedId(latest.id);
  }, [canonicalTeams]);

  const team = canonicalTeams.find(t => t.id === selectedId);
  const roster = players.filter(p => p.team_id === selectedId);
  const totals = roster.reduce((acc, p) => {
    acc.goals += Number(p.goals) || 0;
    acc.assists += Number(p.assists) || 0;
    acc.yc += Number(p.yellow_cards) || 0;
    acc.rc += Number(p.red_cards) || 0;
    acc.saves += Number(p.saves) || 0;
    acc.conceded += Number(p.goals_conceded) || 0;
    return acc;
  }, { goals:0, assists:0, yc:0, rc:0, saves:0, conceded:0 });

  // standings for two-team league context
  const twoTeams = canonicalTeams.slice().reverse().slice(0,2);
  const validIds = new Set(twoTeams.map(t=>t.id));
  const leagueMatches = matches.slice().reverse().filter(m => validIds.has(m.home_team_id) && validIds.has(m.away_team_id));
  const standings = computeStandings(twoTeams, leagueMatches);
  const standingRow = standings.find(r => r.team.id === selectedId);

  return (
    <div className="panel">
      <div className="section-title">Team View</div>
      <div className="input-row">
        <select value={selectedId} onChange={(e)=>setSelectedId(e.target.value)}>
          {canonicalTeams.slice().reverse().map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
      </div>

      {team ? (
        <div className="item" style={{ alignItems: 'flex-start' }}>
          <img className="team-avatar" src={team.avatar_url || 'https://images.websim.com/avatar/' + (team.username || 'team')} alt="" />
          <div className="meta">
            <div><strong>{team.name}</strong></div>
            <div className="small">Players: {roster.length}</div>
            <div className="small">Totals — Goals: {totals.goals} · Assists: {totals.assists} · YC: {totals.yc} · RC: {totals.rc} · Saves: {totals.saves} · Conceded: {totals.conceded}</div>
            {standingRow && (
              <div className="small">League — Played: {standingRow.played} · W: {standingRow.wins} · D: {standingRow.draws} · L: {standingRow.losses} · GF: {standingRow.gf} · GA: {standingRow.ga} · GD: {standingRow.gd} · Pts: {standingRow.pts}</div>
            )}
          </div>
        </div>
      ) : (
        <div className="small">Select a team to view data.</div>
      )}

      <div className="section-title" style={{ marginTop: 10 }}>Roster</div>
      <div className="list">
        {roster.map(p => (
          <div key={p.id} className="item">
            <img className="avatar" src={p.avatar_url || DEFAULT_PLAYER_IMG} alt="" />
            <div className="meta">
              <div><strong>#{p.number || '—'} {p.name}</strong> <span className="small">({p.position || '—'})</span></div>
              <div className="small">Goals: {p.goals||0} · Assists: {p.assists||0} · YC: {p.yellow_cards||0} · RC: {p.red_cards||0} · Saves: {p.saves||0} · Conceded: {p.goals_conceded||0}</div>
            </div>
          </div>
        ))}
        {roster.length === 0 && <div className="small">No players on this team yet.</div>}
      </div>
    </div>
  );
}

function App() {
  const [authed, setAuthed] = useState(false);
  const [tab, setTab] = useState('players');
  const [startChosen, setStartChosen] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [dark, setDark] = useState(() => {
    try { return localStorage.getItem('darkMode') === 'true'; } catch { return false; }
  });

  useEffect(() => {
    ensureDefaultTeams();
  }, []);

  useEffect(() => {
    document.body.classList.toggle('dark', dark);
    try { localStorage.setItem('darkMode', dark ? 'true' : 'false'); } catch {}
  }, [dark]);

  return (
    <div>
      {!startChosen && (
        <StartGate
          onChooseAdmin={() => { setStartChosen(true); setShowLogin(true); }}
          onChooseGuest={() => { setStartChosen(true); setShowLogin(false); }}
        />
      )}
      {showLogin && !authed && <LoginGate onAuthed={setAuthed} />}

      <div className="header">
        <div className="title">Soccer Database</div>
        <div className="row" style={{ alignItems: 'center' }}>
          <label className="small" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <input
              type="checkbox"
              checked={dark}
              onChange={(e)=>setDark(e.target.checked)}
              aria-label="Toggle dark mode"
            />
            Dark mode
          </label>
          {authed ? <span className="small">Admin active</span> : <span className="small">Read-only</span>}
        </div>
      </div>

      <div className="tabs">
        <div className={`tab ${tab==='players'?'active':''}`} onClick={()=>setTab('players')}>Players</div>
        <div className={`tab ${tab==='league'?'active':''}`} onClick={()=>setTab('league')}>League</div>
        <div className={`tab ${tab==='market'?'active':''}`} onClick={()=>setTab('market')}>Market</div>
        <div className={`tab ${tab==='team'?'active':''}`} onClick={()=>setTab('team')}>Team View</div>
      </div>

      {tab === 'players' && <PlayersManager authed={authed} />}
      {tab === 'league' && <LeagueManager authed={authed} />}
      {tab === 'market' && <Market authed={authed} />}
      {tab === 'team' && <TeamView />}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('app')).render(<App />);